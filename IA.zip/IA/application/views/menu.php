<div class="pos-f-t">
  <div class="collapse" id="navbarToggleExternalContent">
    <div class="bg-dark p-4">
      

      <ul class="nav nav-pills">
  <li class="nav-item">
    <a class="nav-link active" href="#">Home</a>
  </li>
  <li class="nav-item dropdown">
    <a class="nav-link dropdown-toggle" data-toggle="dropdown" href="#" role="button" aria-haspopup="true" aria-expanded="false">Cardápio</a>
    <div class="dropdown-menu">
      <a class="dropdown-item" href="#">Entradas</a>
      <a class="dropdown-item" href="#">Bebidas</a>
      <a class="dropdown-item" href="#">Refeições</a>
      <a class="dropdown-item" href="#">Sobremesas</a>
    </div>
  </li>
  <li class="nav-item">
    <a class="nav-link" href="#">Mesa</a>
  </li>
   <li class="nav-item">
    <a class="nav-link" href="#">Conta</a>
  </li>
   <li class="nav-item">
    <a class="nav-link" href="#">Atendente</a>
  </li>
  

    </div>
  </div>
  <nav class="navbar navbar-dark bg-dark">
    <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarToggleExternalContent" aria-controls="navbarToggleExternalContent" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button>
  </nav>
</div>