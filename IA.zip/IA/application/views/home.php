
<!--  Titulo  -->
<div style="text-align: center; margin-top: 30px">     
   <h2><b>Nome do Restaurante</b></h2>
</div>
   
<!-- Imagem  --> 
<div class="text-center" style="margin-top: 20px">
     <img src="assets/img/fototopo.jpg" class="img-fluid" alt="Responsive image" style="text-align: center">
</div>
 
             
<div id="nomerestaurante" style="margin-top: 20px; text-align: center;" >
    <div>
    <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Integer pharetra neque a diam cursus pulvinar. Suspendisse faucibus mi id accumsan lobortis. Pellentesque consectetur varius turpis, nec viverra justo pellentesque sit amet. Vestibulum convallis leo non purus vehicula, non faucibus libero rhoncus. Morbi aliquam tincidunt facilisis. Aenean sodales nulla ac semper consectetur. Vivamus commodo massa convallis justo posuere vestibulum. Aenean congue non mauris ac auctor. Ut suscipit et eros nec suscipit. Nulla congue, mauris nec bibendum sagittis, urna orci tincidunt massa, in vulputate velit nulla vitae nunc. Etiam urna justo, imperdiet nec orci sollicitudin, tempus feugiat erat. Vivamus id lectus nulla. Vestibulum sagittis cursus metus vel ultricies. <a href="https://github.com/christophery/pushy">Suspendisse viverra</a> interdum metus eu placerat. Quisque tristique velit nisi, scelerisque consectetur tortor vehicula ut. Donec id fermentum mi, nec venenatis felis.</p>

    </div>
 </div>